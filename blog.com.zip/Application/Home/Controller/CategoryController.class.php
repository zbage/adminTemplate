<?php
/**
 * Time: 14-3-2 下午4:17
 */
namespace Home\Controller;

use Common\Controller\ApiController;

class CategoryController extends ApiController
{
	public function index($alias = '')
	{

	}
} 