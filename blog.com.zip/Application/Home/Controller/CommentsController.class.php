<?php
/**
 * Time: 14-3-2 下午4:18
 */

namespace Home\Controller;


use Common\Controller\ApiController;

class CommentsController extends ApiController {

} 