<?php
return array(
	'LOAD_EXT_CONFIG'=>'attributes'
);