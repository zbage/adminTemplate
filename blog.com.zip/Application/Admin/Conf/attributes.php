<?php
	//常量定义
	return array(
		'VERSION'=>'1.0 release 20140302',
		'SETTINGS_GROUP'  =>array(
			'基本设置'  =>  1,
			'高级设置'  =>  2,
		)
	);