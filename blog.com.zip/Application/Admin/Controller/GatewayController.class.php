<?php
/**
 * Time: 14-3-2 下午6:12
 */

namespace Admin\Controller;


class GatewayController extends Controller {

} 