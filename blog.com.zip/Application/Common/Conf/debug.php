<?php
//DEBUG模式配置
return array(
	'URL_MODEL' => 2,
	'DB_TYPE' => 'mysqli',
//	'DB_HOST' => 'localhost',
//	'DB_USER' => 'root',
//'DB_PWD' => 'root',
	//'DB_PREFIX' => '',
//	'DB_NAME' => 'blog',
	'DB_HOST' => 'mysql.5jelly.com',
	'DB_USER' => 'u837319938_blog',
	'DB_PWD' => 'root',
	'DB_PREFIX' => 'xialei123!',
	'DB_NAME' => 'u837319938_blog',
	//'SHOW_PAGE_TRACE' => true,
	'URL_CASE_INSENSITIVE' => true,
	'DATA_CACHE_TYPE' => 'Db',
	'DATA_CACHE_TABLE' => 'cache',
	'URL_PARAMS_BIND' => true,

);